<<<<<<< HEAD
#searchFile <- read.csv(paste("MyData",x,".csv"))
setwd("Wannacry")
ficheros <- dir()
for(fichero in ficheros){
  print(fichero)
}
=======
#searchFile <- read.csv(paste("MyData",x,".csv"))
setwd("Wannacry")
ficheros <- dir()
for(fichero in ficheros){
  print(fichero)
}
>>>>>>> b34f19c0ca8338f96da9f3aec002d398318116e1
